# Core Concepts

We will be learning the core concepts in Vuex in this chapters. They are
  - [State](state.md)
  - [Getters](getters.md)
  - [Mutations](mutations.md)
  - [Actions](actions.md)
  - [Modules](modules.md)

A deep understanding of all these concepts is essential for using vuex. 

Let's get started.
